/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';

import { CowComponent } from './Cow/Cow.component';
import { CowAuctionListingComponent } from './CowAuctionListing/CowAuctionListing.component';

import { FarmerComponent } from './Farmer/Farmer.component';
import { VentinaryDocComponent } from './VentinaryDoc/VentinaryDoc.component';

import { RegisterFarmerComponent } from './RegisterFarmer/RegisterFarmer.component';
import { RegisterCowComponent } from './RegisterCow/RegisterCow.component';
import { AddCowSaleListingComponent } from './AddCowSaleListing/AddCowSaleListing.component';
import { RegisterVentinaryDocComponent } from './RegisterVentinaryDoc/RegisterVentinaryDoc.component';
import { VerifyCowHealthComponent } from './VerifyCowHealth/VerifyCowHealth.component';
import { UpdateCowStatusComponent } from './UpdateCowStatus/UpdateCowStatus.component';
import { MakeBidComponent } from './MakeBid/MakeBid.component';
import { CloseBiddingComponent } from './CloseBidding/CloseBidding.component';
import { GiveFeedbackComponent } from './GiveFeedback/GiveFeedback.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'Cow', component: CowComponent },
  { path: 'CowAuctionListing', component: CowAuctionListingComponent },
  { path: 'Farmer', component: FarmerComponent },
  { path: 'VentinaryDoc', component: VentinaryDocComponent },
  { path: 'RegisterFarmer', component: RegisterFarmerComponent },
  { path: 'RegisterCow', component: RegisterCowComponent },
  { path: 'AddCowSaleListing', component: AddCowSaleListingComponent },
  { path: 'RegisterVentinaryDoc', component: RegisterVentinaryDocComponent },
  { path: 'VerifyCowHealth', component: VerifyCowHealthComponent },
  { path: 'UpdateCowStatus', component: UpdateCowStatusComponent },
  { path: 'MakeBid', component: MakeBidComponent },
  { path: 'CloseBidding', component: CloseBiddingComponent },
  { path: 'GiveFeedback', component: GiveFeedbackComponent },
  { path: '**', redirectTo: '' }
];

@NgModule({
 imports: [RouterModule.forRoot(routes)],
 exports: [RouterModule],
 providers: []
})
export class AppRoutingModule { }
