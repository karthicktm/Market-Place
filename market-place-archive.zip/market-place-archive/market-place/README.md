# market-place

create a marketplace solution based on distributed ledger technology to sell or purchase cattle and cow milk
