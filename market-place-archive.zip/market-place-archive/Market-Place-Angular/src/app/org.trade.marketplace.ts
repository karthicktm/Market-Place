import {Asset} from './org.hyperledger.composer.system';
import {Participant} from './org.hyperledger.composer.system';
import {Transaction} from './org.hyperledger.composer.system';
import {Event} from './org.hyperledger.composer.system';
// export namespace org.trade.marketplace{
   export class Cow extends Asset {
      cowId: string;
      owner: Farmer;
      cowAge: number;
      cowBreed: string;
      cowHealthCertificateId: string;
      isHealthCertificateVerified: boolean;
      cowHealthStatus: string;
      verifiedBy: string;
      isAlive: boolean;
   }
   export class Farmer extends Participant {
      farmerId: string;
      farmerName: string;
      farmerDOB: string;
      farmerAuthenticationId: string;
      location: string;
      balance: number;
      rating: string;
   }
   export enum ListingState {
      FOR_SALE,
      SOLD,
   }
   export class CowAuctionListing extends Asset {
      cow: Cow;
      listId: string;
      reservePrice: number;
      description: string;
      state: ListingState;
      offers: MakeBid[];
      buyer: Farmer;
      seller: Farmer;
   }
   export class VentinaryDoc extends Participant {
      docId: string;
      docName: string;
      location: string;
   }
   export class RegisterFarmer extends Transaction {
      farmer: Farmer;
   }
   export class RegisterCow extends Transaction {
      cow: Cow;
   }
   export class AddCowSaleListing extends Transaction {
      cowList: CowAuctionListing;
   }
   export class RegisterVentinaryDoc extends Transaction {
      vDoc: VentinaryDoc;
   }
   export class VerifyCowHealth extends Transaction {
      vDoc: VentinaryDoc;
      cow: Cow;
   }
   export class UpdateCowStatus extends Transaction {
      cow: Cow;
      cowAge: number;
      cowHealthCertificateId: string;
      isAlive: boolean;
   }
   export class MakeBid extends Transaction {
      bidPrice: number;
      listing: CowAuctionListing;
      farmer: Farmer;
   }
   export class CloseBidding extends Transaction {
      listing: CowAuctionListing;
   }
   export class GiveFeedback extends Transaction {
      listing: CowAuctionListing;
      rating: string;
   }
// }
