/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { DataService } from './data.service';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';

import { CowComponent } from './Cow/Cow.component';
import { CowAuctionListingComponent } from './CowAuctionListing/CowAuctionListing.component';

import { FarmerComponent } from './Farmer/Farmer.component';
import { VentinaryDocComponent } from './VentinaryDoc/VentinaryDoc.component';

import { RegisterFarmerComponent } from './RegisterFarmer/RegisterFarmer.component';
import { RegisterCowComponent } from './RegisterCow/RegisterCow.component';
import { AddCowSaleListingComponent } from './AddCowSaleListing/AddCowSaleListing.component';
import { RegisterVentinaryDocComponent } from './RegisterVentinaryDoc/RegisterVentinaryDoc.component';
import { VerifyCowHealthComponent } from './VerifyCowHealth/VerifyCowHealth.component';
import { UpdateCowStatusComponent } from './UpdateCowStatus/UpdateCowStatus.component';
import { MakeBidComponent } from './MakeBid/MakeBid.component';
import { CloseBiddingComponent } from './CloseBidding/CloseBidding.component';
import { GiveFeedbackComponent } from './GiveFeedback/GiveFeedback.component';

  @NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CowComponent,
    CowAuctionListingComponent,
    FarmerComponent,
    VentinaryDocComponent,
    RegisterFarmerComponent,
    RegisterCowComponent,
    AddCowSaleListingComponent,
    RegisterVentinaryDocComponent,
    VerifyCowHealthComponent,
    UpdateCowStatusComponent,
    MakeBidComponent,
    CloseBiddingComponent,
    GiveFeedbackComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    AppRoutingModule
  ],
  providers: [
    DataService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
