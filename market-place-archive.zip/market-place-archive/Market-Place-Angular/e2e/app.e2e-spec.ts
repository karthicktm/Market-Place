/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { AngularTestPage } from './app.po';
import { ExpectedConditions, browser, element, by } from 'protractor';
import {} from 'jasmine';


describe('Starting tests for Market-Place-Angular', function() {
  let page: AngularTestPage;

  beforeEach(() => {
    page = new AngularTestPage();
  });

  it('website title should be Market-Place-Angular', () => {
    page.navigateTo('/');
    return browser.getTitle().then((result)=>{
      expect(result).toBe('Market-Place-Angular');
    })
  });

  it('network-name should be market-place-network@0.0.1',() => {
    element(by.css('.network-name')).getWebElement()
    .then((webElement) => {
      return webElement.getText();
    })
    .then((txt) => {
      expect(txt).toBe('market-place-network@0.0.1.bna');
    });
  });

  it('navbar-brand should be Market-Place-Angular',() => {
    element(by.css('.navbar-brand')).getWebElement()
    .then((webElement) => {
      return webElement.getText();
    })
    .then((txt) => {
      expect(txt).toBe('Market-Place-Angular');
    });
  });

  
    it('Cow component should be loadable',() => {
      page.navigateTo('/Cow');
      browser.findElement(by.id('assetName'))
      .then((assetName) => {
        return assetName.getText();
      })
      .then((txt) => {
        expect(txt).toBe('Cow');
      });
    });

    it('Cow table should have 10 columns',() => {
      page.navigateTo('/Cow');
      element.all(by.css('.thead-cols th')).then(function(arr) {
        expect(arr.length).toEqual(10); // Addition of 1 for 'Action' column
      });
    });
  
    it('CowAuctionListing component should be loadable',() => {
      page.navigateTo('/CowAuctionListing');
      browser.findElement(by.id('assetName'))
      .then((assetName) => {
        return assetName.getText();
      })
      .then((txt) => {
        expect(txt).toBe('CowAuctionListing');
      });
    });

    it('CowAuctionListing table should have 9 columns',() => {
      page.navigateTo('/CowAuctionListing');
      element.all(by.css('.thead-cols th')).then(function(arr) {
        expect(arr.length).toEqual(9); // Addition of 1 for 'Action' column
      });
    });
  

  
    it('Farmer component should be loadable',() => {
      page.navigateTo('/Farmer');
      browser.findElement(by.id('participantName'))
      .then((participantName) => {
        return participantName.getText();
      })
      .then((txt) => {
        expect(txt).toBe('Farmer');
      });
    });

    it('Farmer table should have 8 columns',() => {
      page.navigateTo('/Farmer');
      element.all(by.css('.thead-cols th')).then(function(arr) {
        expect(arr.length).toEqual(8); // Addition of 1 for 'Action' column
      });
    });
  
    it('VentinaryDoc component should be loadable',() => {
      page.navigateTo('/VentinaryDoc');
      browser.findElement(by.id('participantName'))
      .then((participantName) => {
        return participantName.getText();
      })
      .then((txt) => {
        expect(txt).toBe('VentinaryDoc');
      });
    });

    it('VentinaryDoc table should have 4 columns',() => {
      page.navigateTo('/VentinaryDoc');
      element.all(by.css('.thead-cols th')).then(function(arr) {
        expect(arr.length).toEqual(4); // Addition of 1 for 'Action' column
      });
    });
  

  
    it('RegisterFarmer component should be loadable',() => {
      page.navigateTo('/RegisterFarmer');
      browser.findElement(by.id('transactionName'))
      .then((transactionName) => {
        return transactionName.getText();
      })
      .then((txt) => {
        expect(txt).toBe('RegisterFarmer');
      });
    });
  
    it('RegisterCow component should be loadable',() => {
      page.navigateTo('/RegisterCow');
      browser.findElement(by.id('transactionName'))
      .then((transactionName) => {
        return transactionName.getText();
      })
      .then((txt) => {
        expect(txt).toBe('RegisterCow');
      });
    });
  
    it('AddCowSaleListing component should be loadable',() => {
      page.navigateTo('/AddCowSaleListing');
      browser.findElement(by.id('transactionName'))
      .then((transactionName) => {
        return transactionName.getText();
      })
      .then((txt) => {
        expect(txt).toBe('AddCowSaleListing');
      });
    });
  
    it('RegisterVentinaryDoc component should be loadable',() => {
      page.navigateTo('/RegisterVentinaryDoc');
      browser.findElement(by.id('transactionName'))
      .then((transactionName) => {
        return transactionName.getText();
      })
      .then((txt) => {
        expect(txt).toBe('RegisterVentinaryDoc');
      });
    });
  
    it('VerifyCowHealth component should be loadable',() => {
      page.navigateTo('/VerifyCowHealth');
      browser.findElement(by.id('transactionName'))
      .then((transactionName) => {
        return transactionName.getText();
      })
      .then((txt) => {
        expect(txt).toBe('VerifyCowHealth');
      });
    });
  
    it('UpdateCowStatus component should be loadable',() => {
      page.navigateTo('/UpdateCowStatus');
      browser.findElement(by.id('transactionName'))
      .then((transactionName) => {
        return transactionName.getText();
      })
      .then((txt) => {
        expect(txt).toBe('UpdateCowStatus');
      });
    });
  
    it('MakeBid component should be loadable',() => {
      page.navigateTo('/MakeBid');
      browser.findElement(by.id('transactionName'))
      .then((transactionName) => {
        return transactionName.getText();
      })
      .then((txt) => {
        expect(txt).toBe('MakeBid');
      });
    });
  
    it('CloseBidding component should be loadable',() => {
      page.navigateTo('/CloseBidding');
      browser.findElement(by.id('transactionName'))
      .then((transactionName) => {
        return transactionName.getText();
      })
      .then((txt) => {
        expect(txt).toBe('CloseBidding');
      });
    });
  
    it('GiveFeedback component should be loadable',() => {
      page.navigateTo('/GiveFeedback');
      browser.findElement(by.id('transactionName'))
      .then((transactionName) => {
        return transactionName.getText();
      })
      .then((txt) => {
        expect(txt).toBe('GiveFeedback');
      });
    });
  

});